var calculation_8cpp =
[
    [ "determinant", "calculation_8cpp.html#ab08d8bee34a930b77dcd300c45ad73e5", null ],
    [ "gem", "calculation_8cpp.html#ab9a07ac29b2541fb2b81c2949ad60662", null ],
    [ "root", "calculation_8cpp.html#aa355c9435e94a5736668a6cc23b446c8", null ],
    [ "whatToSave", "calculation_8cpp.html#a015e157d4ea7fc8050e21c0da0f20348", null ]
];