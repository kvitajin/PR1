var searchData=
[
  ['terminalbranch',['terminalBranch',['../funkce_8cpp.html#ae0e212aafbdeab9fe31c783e1677f17e',1,'terminalBranch(std::vector&lt; std::vector&lt; double &gt; &gt; &amp;matrix):&#160;funkce.cpp'],['../funkce_8h.html#ae0e212aafbdeab9fe31c783e1677f17e',1,'terminalBranch(std::vector&lt; std::vector&lt; double &gt; &gt; &amp;matrix):&#160;funkce.cpp']]],
  ['terminalfillmatrix',['terminalFillMatrix',['../funkce_8cpp.html#aeba2870968be2af627125a5db85950e1',1,'terminalFillMatrix(std::vector&lt; std::vector&lt; double &gt; &gt; &amp;matrix):&#160;funkce.cpp'],['../funkce_8h.html#aeba2870968be2af627125a5db85950e1',1,'terminalFillMatrix(std::vector&lt; std::vector&lt; double &gt; &gt; &amp;matrix):&#160;funkce.cpp']]]
];
