var searchData=
[
  ['determinant',['determinant',['../calcilation_8h.html#ab08d8bee34a930b77dcd300c45ad73e5',1,'determinant(std::vector&lt; std::vector&lt; double &gt; &gt; &amp;matrix, long int &amp;determ):&#160;calculation.cpp'],['../calculation_8cpp.html#ab08d8bee34a930b77dcd300c45ad73e5',1,'determinant(std::vector&lt; std::vector&lt; double &gt; &gt; &amp;matrix, long int &amp;determ):&#160;calculation.cpp']]]
];
