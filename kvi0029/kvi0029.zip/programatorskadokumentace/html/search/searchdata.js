var indexSectionsWithContent =
{
  0: "cdfgimoprtvw",
  1: "cfmor",
  2: "dfgimoprtvw",
  3: "m"
};

var indexSectionNames =
{
  0: "all",
  1: "files",
  2: "functions",
  3: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Files",
  2: "Functions",
  3: "Pages"
};

