var searchData=
[
  ['whattosave',['whatToSave',['../calcilation_8h.html#a015e157d4ea7fc8050e21c0da0f20348',1,'whatToSave():&#160;calculation.cpp'],['../calculation_8cpp.html#a015e157d4ea7fc8050e21c0da0f20348',1,'whatToSave():&#160;calculation.cpp']]],
  ['wheretosavefinalsolution',['whereToSaveFinalSolution',['../out_8cpp.html#a3437da024b5ff6e4479f34c2fc1da3b5',1,'whereToSaveFinalSolution():&#160;out.cpp'],['../out_8h.html#a3437da024b5ff6e4479f34c2fc1da3b5',1,'whereToSaveFinalSolution():&#160;out.cpp']]]
];
