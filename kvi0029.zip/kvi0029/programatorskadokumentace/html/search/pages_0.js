var searchData=
[
  ['maticové_20operace',['Maticové operace',['../md__r_e_a_d_m_e.html',1,'']]]
];
