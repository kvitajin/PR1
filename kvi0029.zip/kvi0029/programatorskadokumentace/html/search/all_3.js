var searchData=
[
  ['gem',['gem',['../calcilation_8h.html#a8cefea3aed229212e275130253a8c28d',1,'gem(std::vector&lt; std::vector&lt; double &gt; &gt; &amp;matrix):&#160;calculation.cpp'],['../calculation_8cpp.html#ab9a07ac29b2541fb2b81c2949ad60662',1,'gem(std::vector&lt; std::vector&lt; double &gt; &gt; &amp;matice):&#160;calculation.cpp']]]
];
