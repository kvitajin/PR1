var searchData=
[
  ['root',['root',['../calcilation_8h.html#aa355c9435e94a5736668a6cc23b446c8',1,'root(std::vector&lt; std::vector&lt; double &gt; &gt; &amp;matrix, std::vector&lt; double &gt; &amp;roots):&#160;calculation.cpp'],['../calculation_8cpp.html#aa355c9435e94a5736668a6cc23b446c8',1,'root(std::vector&lt; std::vector&lt; double &gt; &gt; &amp;matrix, std::vector&lt; double &gt; &amp;roots):&#160;calculation.cpp']]]
];
