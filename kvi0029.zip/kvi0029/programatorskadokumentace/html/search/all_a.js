var searchData=
[
  ['velikostmatice',['velikostMatice',['../funkce_8cpp.html#a631dba024210ec7de78fe6649998c2d4',1,'velikostMatice(int &amp;rows, int &amp;columns):&#160;funkce.cpp'],['../funkce_8h.html#a631dba024210ec7de78fe6649998c2d4',1,'velikostMatice(int &amp;rows, int &amp;columns):&#160;funkce.cpp']]]
];
