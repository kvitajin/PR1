var calcilation_8h =
[
    [ "determinant", "calcilation_8h.html#ab08d8bee34a930b77dcd300c45ad73e5", null ],
    [ "gem", "calcilation_8h.html#a8cefea3aed229212e275130253a8c28d", null ],
    [ "root", "calcilation_8h.html#aa355c9435e94a5736668a6cc23b446c8", null ],
    [ "whatToSave", "calcilation_8h.html#a015e157d4ea7fc8050e21c0da0f20348", null ]
];